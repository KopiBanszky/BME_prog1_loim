typedef struct Settings_menu_Param {
    Regular_Data *lists;
    Properties *settings;
    Properties *preview;
} Settings_menu_Param;

Page_Func settings_menu(void* param);