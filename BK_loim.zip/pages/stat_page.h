#include "../libs/utility.h"

typedef struct Stats_menu_Params{
    Settings_menu_Param *settings_type;
    bool unfiltered;
} Stats_menu_Params;

Page_Func stat_menu(void* param);