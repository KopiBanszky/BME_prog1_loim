#ifndef READ_DATA_H
#define READ_DATA_H

typedef struct Choose_By_Question{
    int difficulty;
    char *question;
    char *answerA;
    char *answerB;
    char *answerC;
    char *answerD;
    char answer;
    char *category;
    struct Choose_By_Question *next;
} Choose_By_Question;

typedef struct Difficulties_list{
    Choose_By_Question *question;
    struct Difficulties_list *next;
} Difficulties_list;

typedef enum FILE_TYPE{
    LOIM,
    SOROK
} File_type;

//extern char loimFILE[500];
//extern char sorokFILE[500];
//extern Difficulties_list *list_for_different_difficulties[16];

//int validate_files(char *loimFILE, char *sorokFILE);

char *validate_file(char *path, File_type fileType);


//char *getLineFromFile(int line, char *pathToFile /* string */);

//Choose_By_Question add_loim_string_to_struct(char *str);

Choose_By_Question *load_loim_in_dinlist(char *pathToFile, Difficulties_list *list_for_different_difficulties[]);
#endif // READ_DATA_H