#include "../libs/utility.h"


Page_Func stat_menu(void* param);